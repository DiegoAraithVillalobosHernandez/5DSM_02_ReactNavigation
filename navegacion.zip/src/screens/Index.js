import React from "react";
import { Text, View } from "react-native";

export default function Index(){
    return(
        <View>
            <Text>Mi index</Text>
        </View>
    )
}