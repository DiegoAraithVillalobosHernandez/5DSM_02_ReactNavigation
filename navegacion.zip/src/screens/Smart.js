import React from "react";
import { Text, View } from "react-native";

export default function Smart(){
    return(
        <View>
            <Text>Mi smart</Text>
        </View>
    )
}