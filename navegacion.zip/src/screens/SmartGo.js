import React from "react";
import { Text, View } from "react-native";

export default function SmartGo(){
    return(
        <View>
            <Text>Mi smartgo</Text>
        </View>
    )
}