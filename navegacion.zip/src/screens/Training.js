import React from "react";
import { Text, View } from "react-native";

export default function Training(){
    return(
        <View>
            <Text>Mi training</Text>
        </View>
    )
}